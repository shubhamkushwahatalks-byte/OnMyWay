import React, { useState } from 'react';
import { Sparkles, MapPin, ArrowRight, Star } from './Icons';
import { getTripSuggestions } from '../services/geminiService';
import { TripSuggestion } from '../types';

interface AIPlannerProps {
  onSelectDestination: (destination: string) => void;
}

const AIPlanner: React.FC<AIPlannerProps> = ({ onSelectDestination }) => {
  const [origin, setOrigin] = useState('');
  const [vibe, setVibe] = useState('');
  const [suggestions, setSuggestions] = useState<TripSuggestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);

  const vibes = ["Nature & Hiking", "City & Nightlife", "Beach & Relax", "Food & Culture", "Hidden Gems"];

  const handleInspireMe = async () => {
    if (!vibe) return;
    setLoading(true);
    setSearched(true);
    const results = await getTripSuggestions(origin, vibe);
    setSuggestions(results);
    setLoading(false);
  };

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-8">
      <div className="bg-gradient-to-br from-indigo-600 to-brand-dark rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden mb-12">
        
        {/* Decorative background circles */}
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-indigo-500/30 rounded-full blur-3xl"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-6">
            <Sparkles className="w-8 h-8 text-yellow-300" />
            <h2 className="text-3xl font-bold">Where will the road take you next?</h2>
          </div>
          
          <p className="text-indigo-100 text-lg mb-8 max-w-2xl">
            Not sure where to go? Tell us your starting point and what you're in the mood for, and our AI will find the perfect carpool destination for you.
          </p>

          <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div className="space-y-2">
                <label className="text-sm font-medium text-indigo-200">Starting from</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-indigo-200" />
                  <input 
                    type="text" 
                    value={origin}
                    onChange={(e) => setOrigin(e.target.value)}
                    placeholder="Current Location (City)"
                    className="w-full bg-black/20 border border-white/10 rounded-xl h-12 pl-12 pr-4 text-white placeholder:text-indigo-200/50 focus:outline-none focus:ring-2 focus:ring-white/50"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-indigo-200">I'm in the mood for</label>
                <div className="flex flex-wrap gap-2">
                  {vibes.map((v) => (
                    <button
                      key={v}
                      onClick={() => setVibe(v)}
                      className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                        vibe === v 
                          ? 'bg-white text-indigo-600 shadow-lg scale-105' 
                          : 'bg-white/10 hover:bg-white/20 text-white border border-white/10'
                      }`}
                    >
                      {v}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={handleInspireMe}
              disabled={loading || !vibe}
              className={`w-full md:w-auto px-8 py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${
                loading || !vibe
                  ? 'bg-gray-500/50 cursor-not-allowed text-gray-300'
                  : 'bg-white text-indigo-600 hover:bg-indigo-50 hover:shadow-lg'
              }`}
            >
              {loading ? (
                <>
                  <Sparkles className="w-5 h-5 animate-spin" />
                  Thinking...
                </>
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  Inspire Me
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Results Section */}
      {searched && !loading && (
        <div className="space-y-6 animate-fade-in-up">
          <h3 className="text-2xl font-bold text-gray-800">Recommended Destinations</h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {suggestions.map((trip, idx) => (
              <div key={idx} className="bg-white rounded-2xl border border-gray-100 shadow-lg hover:shadow-xl transition-all overflow-hidden group flex flex-col h-full">
                <div className="h-32 bg-indigo-100 relative overflow-hidden">
                   {/* Abstract Placeholder for City Image */}
                   <div className="absolute inset-0 bg-gradient-to-tr from-brand to-indigo-500 opacity-80"></div>
                   <div className="absolute bottom-4 left-4 text-white">
                      <span className="text-xs font-bold uppercase tracking-wider bg-black/20 px-2 py-1 rounded-md backdrop-blur-sm">{trip.vibe}</span>
                   </div>
                </div>
                
                <div className="p-6 flex-1 flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-xl font-bold text-gray-900">{trip.destination}</h4>
                    <span className="text-brand font-bold bg-brand-light px-2 py-1 rounded-lg text-sm">{trip.estimatedPrice}</span>
                  </div>
                  
                  <p className="text-gray-600 mb-6 flex-1">{trip.description}</p>
                  
                  <button 
                    onClick={() => onSelectDestination(trip.destination)}
                    className="w-full py-3 border-2 border-brand text-brand font-bold rounded-xl hover:bg-brand hover:text-white transition-all flex items-center justify-center gap-2 group-hover:gap-4"
                  >
                    Find rides
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          {suggestions.length === 0 && (
             <div className="text-center py-12 text-gray-500">
               <p>No suggestions found. Try a different vibe!</p>
             </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AIPlanner;