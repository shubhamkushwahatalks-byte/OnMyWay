import React, { useState } from 'react';
import { Search, MapPin, Calendar, User, Sparkles, Car, Bike, CarFront, Gift, Navigation } from './Icons';
import { SearchParams, RideType } from '../types';

interface HeroSearchProps {
  onSearch: (params: SearchParams) => void;
  onNavigateAI: () => void;
}

const HeroSearch: React.FC<HeroSearchProps> = ({ onSearch, onNavigateAI }) => {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [passengers, setPassengers] = useState(1);
  const [rideType, setRideType] = useState<RideType>(RideType.CARPOOL);
  const [showFreeOnly, setShowFreeOnly] = useState(false);
  const [isLocating, setIsLocating] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({ from, to, date, passengers, type: rideType, showFreeOnly });
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      alert("Geolocation is not supported by your browser");
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        // In a real app, we would use a geocoding API here.
        // For now, we simulate a found location.
        setTimeout(() => {
          setFrom(`Current Location (${position.coords.latitude.toFixed(2)}, ${position.coords.longitude.toFixed(2)})`);
          setIsLocating(false);
        }, 800);
      },
      (error) => {
        console.error(error);
        setIsLocating(false);
        alert("Unable to retrieve your location. Please check your permissions.");
      }
    );
  };

  return (
    <div className="w-full max-w-5xl mx-auto -mt-20 relative z-20 px-4">
      {/* Mode Selection Tabs */}
      <div className="flex justify-center sm:justify-start gap-1 ml-4">
        <button
          onClick={() => setRideType(RideType.CARPOOL)}
          className={`px-6 py-3 rounded-t-xl font-bold flex items-center gap-2 transition-all ${
            rideType === RideType.CARPOOL 
              ? 'bg-white text-gray-900 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] translate-y-1 z-10' 
              : 'bg-black/60 text-white hover:bg-black/70 backdrop-blur-sm'
          }`}
        >
          <Car className="w-5 h-5" />
          Carpool
        </button>
        <button
          onClick={() => setRideType(RideType.AUTO)}
          className={`px-6 py-3 rounded-t-xl font-bold flex items-center gap-2 transition-all ${
            rideType === RideType.AUTO
              ? 'bg-white text-gray-900 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] translate-y-1 z-10' 
              : 'bg-black/60 text-white hover:bg-black/70 backdrop-blur-sm'
          }`}
        >
          <Bike className="w-5 h-5" />
          Auto
        </button>
        <button
          onClick={() => setRideType(RideType.TAXI)}
          className={`px-6 py-3 rounded-t-xl font-bold flex items-center gap-2 transition-all ${
            rideType === RideType.TAXI
              ? 'bg-white text-gray-900 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] translate-y-1 z-10' 
              : 'bg-black/60 text-white hover:bg-black/70 backdrop-blur-sm'
          }`}
        >
          <CarFront className="w-5 h-5" />
          Taxi
        </button>
      </div>

      <form 
        onSubmit={handleSubmit}
        className="bg-white rounded-2xl rounded-tl-none shadow-2xl p-4 lg:p-6 flex flex-col gap-4 relative z-20 ring-1 ring-black/5"
      >
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          {/* From Input */}
          <div className="flex-1 w-full relative group">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-brand-dark transition-colors z-10">
              <MapPin className="w-5 h-5" />
            </div>
            
            {/* Locate Me Button */}
            <button 
              type="button"
              onClick={handleLocateMe}
              title="Use my current location"
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 hover:bg-brand-light rounded-full text-brand-dark transition-colors z-20"
            >
              <Navigation className={`w-5 h-5 ${isLocating ? 'animate-pulse' : ''}`} />
            </button>

            <input
              type="text"
              placeholder="Leaving from"
              value={from}
              onChange={(e) => setFrom(e.target.value)}
              className="w-full h-14 pl-12 pr-12 bg-gray-50 hover:bg-gray-100 focus:bg-white focus:ring-2 focus:ring-brand focus:outline-none rounded-xl transition-all font-medium text-gray-900 placeholder:text-gray-500 truncate"
              required
            />
          </div>

          {/* To Input */}
          <div className="flex-1 w-full relative group">
             <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-brand-dark transition-colors">
              <MapPin className="w-5 h-5" />
            </div>
            <input
              type="text"
              placeholder="Going to"
              value={to}
              onChange={(e) => setTo(e.target.value)}
              className="w-full h-14 pl-12 pr-4 bg-gray-50 hover:bg-gray-100 focus:bg-white focus:ring-2 focus:ring-brand focus:outline-none rounded-xl transition-all font-medium text-gray-900 placeholder:text-gray-500 truncate"
              required
            />
          </div>

          {/* Date Input */}
          <div className="w-full lg:w-48 relative group">
             <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-brand-dark transition-colors">
              <Calendar className="w-5 h-5" />
            </div>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full h-14 pl-12 pr-4 bg-gray-50 hover:bg-gray-100 focus:bg-white focus:ring-2 focus:ring-brand focus:outline-none rounded-xl transition-all font-medium text-gray-900 cursor-pointer"
            />
          </div>

          {/* Passenger Input */}
          <div className="w-full lg:w-28 relative group">
             <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 group-focus-within:text-brand-dark transition-colors">
              <User className="w-5 h-5" />
            </div>
            <input
              type="number"
              min="1"
              max="8"
              value={passengers}
              onChange={(e) => setPassengers(parseInt(e.target.value))}
              className="w-full h-14 pl-12 pr-4 bg-gray-50 hover:bg-gray-100 focus:bg-white focus:ring-2 focus:ring-brand focus:outline-none rounded-xl transition-all font-medium text-gray-900"
            />
          </div>

          {/* Search Button */}
          <button 
            type="submit"
            className="w-full lg:w-auto h-14 px-8 bg-brand hover:bg-brand-dark text-brand-contrast font-bold text-lg rounded-xl transition-colors shadow-lg shadow-brand/20 flex items-center justify-center gap-2"
          >
            <Search className="w-6 h-6" />
            <span className="lg:hidden">Find Rides</span>
          </button>
        </div>

        {/* Free Ride Toggle */}
        <div className="flex items-center gap-4 pt-2 border-t border-gray-100">
           <label className="flex items-center gap-2 cursor-pointer group select-none">
             <div className={`w-12 h-6 rounded-full p-1 transition-colors duration-300 ease-in-out ${showFreeOnly ? 'bg-green-500' : 'bg-gray-200'}`}>
               <div className={`bg-white w-4 h-4 rounded-full shadow-md transform duration-300 ease-in-out ${showFreeOnly ? 'translate-x-6' : 'translate-x-0'}`}></div>
             </div>
             <input 
              type="checkbox" 
              className="hidden" 
              checked={showFreeOnly}
              onChange={(e) => setShowFreeOnly(e.target.checked)}
             />
             <div className="flex items-center gap-2">
               <Gift className={`w-5 h-5 ${showFreeOnly ? 'text-green-600' : 'text-gray-400'}`} />
               <span className={`font-medium ${showFreeOnly ? 'text-green-700' : 'text-gray-600'}`}>Show FREE Community Rides</span>
             </div>
           </label>
        </div>
      </form>

      {/* AI Prompt Teaser */}
      <div className="mt-6 flex justify-center">
         <button 
          onClick={onNavigateAI}
          className="bg-white/95 backdrop-blur-sm hover:bg-white hover:scale-105 text-gray-800 px-6 py-2.5 rounded-full text-sm font-bold shadow-lg transition-all flex items-center gap-2 border-2 border-brand"
         >
           <Sparkles className="w-4 h-4 text-brand-dark" />
           Not sure where to go? Ask AI for ideas
         </button>
      </div>
    </div>
  );
};

export default HeroSearch;