import React from 'react';
import { ShieldCheck, Star, Smartphone } from './Icons';

const AppDownload: React.FC = () => {
  return (
    <section className="py-20 bg-gray-900 text-white relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 right-0 w-1/2 h-full bg-brand/10 blur-3xl rounded-l-full"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/20 blur-3xl rounded-r-full"></div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center gap-12">
          
          <div className="flex-1 space-y-8">
            <span className="inline-block bg-brand text-gray-900 text-xs font-black px-3 py-1 rounded-full uppercase tracking-widest">
              Available Now
            </span>
            <h2 className="text-4xl md:text-5xl font-black leading-tight">
              Drive, Ride, & Track <br />
              <span className="text-brand">All in One App</span>
            </h2>
            <p className="text-gray-300 text-lg leading-relaxed max-w-xl">
              Get the full experience with our mobile app. Real-time tracking, secure payments, and instant verified driver matching.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="flex items-center gap-3 bg-white text-gray-900 px-6 py-3 rounded-xl hover:bg-gray-100 transition-colors">
                <img src="https://cdn-icons-png.flaticon.com/512/888/888857.png" alt="Play Store" className="w-8 h-8" />
                <div className="text-left">
                  <div className="text-xs font-bold text-gray-500">GET IT ON</div>
                  <div className="text-lg font-black leading-none">Google Play</div>
                </div>
              </button>
              <button className="flex items-center gap-3 bg-white/10 text-white border border-white/20 px-6 py-3 rounded-xl hover:bg-white/20 transition-colors">
                <img src="https://cdn-icons-png.flaticon.com/512/888/888841.png" alt="App Store" className="w-8 h-8 invert" />
                <div className="text-left">
                  <div className="text-xs font-bold text-gray-400">Download on the</div>
                  <div className="text-lg font-black leading-none">App Store</div>
                </div>
              </button>
            </div>

            <div className="flex items-center gap-6 pt-4 text-sm font-medium text-gray-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-green-400" />
                Secure Payments
              </div>
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-brand" />
                4.8/5 Rating
              </div>
            </div>
          </div>

          <div className="flex-1 flex justify-center relative">
             {/* Abstract Phone Mockup */}
             <div className="relative w-72 h-[550px] bg-black border-8 border-gray-800 rounded-[3rem] shadow-2xl overflow-hidden ring-4 ring-gray-900/50">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-black rounded-b-xl z-20"></div>
                <div className="w-full h-full bg-white relative">
                   {/* Mock App UI */}
                   <div className="bg-brand h-1/3 w-full p-6 flex flex-col justify-end">
                      <h3 className="text-gray-900 font-black text-2xl">Hello, Rider!</h3>
                      <p className="text-gray-800 text-sm">Where to today?</p>
                   </div>
                   <div className="p-4 space-y-3">
                      <div className="h-16 bg-gray-100 rounded-xl w-full animate-pulse"></div>
                      <div className="h-16 bg-gray-100 rounded-xl w-full animate-pulse delay-75"></div>
                      <div className="h-16 bg-gray-100 rounded-xl w-full animate-pulse delay-150"></div>
                   </div>
                   <div className="absolute bottom-0 w-full bg-gray-50 p-4 border-t border-gray-200">
                      <div className="flex justify-around text-gray-400">
                          <Smartphone className="w-6 h-6 text-brand" />
                          <div className="w-6 h-6 rounded-full bg-gray-300"></div>
                          <div className="w-6 h-6 rounded-full bg-gray-300"></div>
                      </div>
                   </div>
                </div>
             </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default AppDownload;