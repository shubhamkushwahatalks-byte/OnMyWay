import React from 'react';
import { PlusCircle, User, Search } from './Icons';
import { AppView } from '../types';

interface HeaderProps {
  onNavigate: (view: AppView) => void;
  currentView: AppView;
}

const Header: React.FC<HeaderProps> = ({ onNavigate, currentView }) => {
  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-100 h-16 flex items-center shadow-sm">
      <div className="container mx-auto px-4 flex justify-between items-center h-full">
        {/* Logo */}
        <div 
          className="flex items-center gap-2 cursor-pointer group" 
          onClick={() => onNavigate(AppView.LANDING)}
        >
          <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center text-brand-contrast font-black text-xl shadow-lg transform group-hover:rotate-12 transition-transform">
            OMW
          </div>
          <span className="text-2xl font-black text-brand-contrast hidden sm:block tracking-tight">On My Way</span>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4 sm:gap-6">
          <button 
            className="flex items-center gap-2 text-gray-600 font-bold hover:text-brand-dark transition-colors"
            onClick={() => onNavigate(AppView.AI_PLANNER)}
          >
            <Search className="w-5 h-5" />
            <span className="hidden sm:inline">Find a ride</span>
          </button>
          
          <button 
            className="flex items-center gap-2 text-brand-contrast font-bold hover:text-brand transition-colors"
            onClick={() => onNavigate(AppView.DRIVER_REGISTRATION)}
          >
            <PlusCircle className="w-5 h-5" />
            <span className="hidden sm:inline">Offer a ride</span>
          </button>

          <div className="flex items-center gap-1 text-gray-500 hover:text-gray-900 cursor-pointer bg-brand-light p-2 rounded-full border border-brand/20 hover:border-brand transition-all">
            <User className="w-5 h-5 text-brand-dark" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;