import { 
  Search, 
  MapPin, 
  Calendar, 
  User, 
  ShieldCheck, 
  Car, 
  Star, 
  Zap,
  ChevronRight,
  PlusCircle,
  Sparkles,
  ArrowRight,
  CarFront, // For Taxi
  Bike, // For Auto representation
  Gift, // For Free rides
  Navigation, // For geolocation
  Smartphone,
  Check,
  Upload,
  FileText
} from 'lucide-react';

export {
  Search,
  MapPin,
  Calendar,
  User,
  ShieldCheck,
  Car,
  Star,
  Zap,
  ChevronRight,
  PlusCircle,
  Sparkles,
  ArrowRight,
  CarFront,
  Bike,
  Gift,
  Navigation,
  Smartphone,
  Check,
  Upload,
  FileText
};