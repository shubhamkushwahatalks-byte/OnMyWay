import React, { useState } from 'react';
import { Car, Bike, CarFront, Check, ShieldCheck, Upload, FileText } from './Icons';

const DriverRegistration: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [vehicleType, setVehicleType] = useState<'CAR' | 'AUTO' | 'TAXI'>('CAR');
  const [dlFile, setDlFile] = useState<string | null>(null);
  const [rcFile, setRcFile] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate API call
    setTimeout(() => {
      setSubmitted(true);
    }, 1000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, setFile: (name: string) => void) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0].name);
    }
  };

  if (submitted) {
    return (
      <div className="max-w-xl mx-auto py-20 px-4 text-center">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <Check className="w-12 h-12 text-green-600" />
        </div>
        <h2 className="text-3xl font-black text-gray-900 mb-4">Registration Pending!</h2>
        <p className="text-gray-600 text-lg mb-8">
          Thank you for registering your vehicle. Our team will verify your documents (DL & RC) shortly. You can track status in the Partner App.
        </p>
        <div className="bg-gray-50 p-6 rounded-2xl border border-gray-200 inline-block">
           <h3 className="font-bold text-gray-900 mb-2">Next Steps:</h3>
           <ol className="text-left text-sm text-gray-600 space-y-2 list-decimal list-inside">
             <li>Download <strong>On My Way Partner</strong> App</li>
             <li>Login with your phone number</li>
             <li>Wait for verification approval (approx 2 hrs)</li>
             <li>Start accepting rides!</li>
           </ol>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-black text-gray-900 mb-4">Drive with On My Way</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Turn your vehicle into an earning machine. Register your Car, Auto, or Taxi and join India's largest community transport network.
        </p>
      </div>

      <div className="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden flex flex-col md:flex-row">
        {/* Left Side - Info */}
        <div className="bg-brand p-8 md:w-1/3 text-brand-contrast">
          <h3 className="text-2xl font-bold mb-6">Why Drive?</h3>
          <ul className="space-y-6">
            <li className="flex items-start gap-3">
              <div className="bg-white/20 p-2 rounded-lg"><ShieldCheck className="w-5 h-5" /></div>
              <div>
                <h4 className="font-bold">Zero Commission</h4>
                <p className="text-sm opacity-80">Keep 100% of what you earn on community rides.</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
               <div className="bg-white/20 p-2 rounded-lg"><Check className="w-5 h-5" /></div>
              <div>
                <h4 className="font-bold">Flexible Hours</h4>
                <p className="text-sm opacity-80">Drive whenever you want. No minimum login hours.</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
               <div className="bg-white/20 p-2 rounded-lg"><Upload className="w-5 h-5" /></div>
              <div>
                <h4 className="font-bold">Instant Payouts</h4>
                <p className="text-sm opacity-80">Get paid directly to your bank account instantly.</p>
              </div>
            </li>
          </ul>
        </div>

        {/* Right Side - Form */}
        <div className="p-8 md:w-2/3">
          <h3 className="text-xl font-bold text-gray-900 mb-6">Vehicle Registration</h3>
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Personal Details */}
            <div className="space-y-4">
               <h4 className="text-sm font-black text-gray-400 uppercase tracking-wider">Driver Details</h4>
               <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Full Name</label>
                  <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all" placeholder="As per Driving License" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Phone Number</label>
                  <input type="tel" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all" placeholder="+91 XXXXX XXXXX" />
                </div>
              </div>
            </div>

            <hr className="border-gray-100" />

            {/* Vehicle Type Selection */}
            <div className="space-y-4">
              <label className="text-sm font-bold text-gray-700">Select Vehicle Type</label>
              <div className="grid grid-cols-3 gap-4">
                <div 
                  onClick={() => setVehicleType('CAR')}
                  className={`cursor-pointer rounded-xl border-2 p-4 flex flex-col items-center gap-2 transition-all ${vehicleType === 'CAR' ? 'border-brand bg-brand-light' : 'border-gray-100 hover:border-gray-300'}`}
                >
                  <Car className={`w-8 h-8 ${vehicleType === 'CAR' ? 'text-brand-dark' : 'text-gray-400'}`} />
                  <span className={`text-sm font-bold ${vehicleType === 'CAR' ? 'text-brand-contrast' : 'text-gray-500'}`}>Car</span>
                </div>
                <div 
                  onClick={() => setVehicleType('AUTO')}
                  className={`cursor-pointer rounded-xl border-2 p-4 flex flex-col items-center gap-2 transition-all ${vehicleType === 'AUTO' ? 'border-brand bg-brand-light' : 'border-gray-100 hover:border-gray-300'}`}
                >
                  <Bike className={`w-8 h-8 ${vehicleType === 'AUTO' ? 'text-brand-dark' : 'text-gray-400'}`} />
                  <span className={`text-sm font-bold ${vehicleType === 'AUTO' ? 'text-brand-contrast' : 'text-gray-500'}`}>Auto</span>
                </div>
                <div 
                  onClick={() => setVehicleType('TAXI')}
                  className={`cursor-pointer rounded-xl border-2 p-4 flex flex-col items-center gap-2 transition-all ${vehicleType === 'TAXI' ? 'border-brand bg-brand-light' : 'border-gray-100 hover:border-gray-300'}`}
                >
                  <CarFront className={`w-8 h-8 ${vehicleType === 'TAXI' ? 'text-brand-dark' : 'text-gray-400'}`} />
                  <span className={`text-sm font-bold ${vehicleType === 'TAXI' ? 'text-brand-contrast' : 'text-gray-500'}`}>Taxi</span>
                </div>
              </div>
            </div>

            {/* Vehicle Details */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Vehicle Number</label>
                <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all uppercase" placeholder="IND - KA 01 AB 1234" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">City</label>
                <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand focus:border-transparent outline-none transition-all" placeholder="e.g. Bangalore" />
              </div>
            </div>

            <hr className="border-gray-100" />

            {/* Document Upload */}
            <div className="space-y-4">
              <h4 className="text-sm font-black text-gray-400 uppercase tracking-wider">Documents Verification</h4>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* Driving License Upload */}
                <div className="space-y-2">
                   <label className="text-sm font-bold text-gray-700">Driving License (DL)</label>
                   <div className={`border-2 border-dashed rounded-xl p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer relative ${dlFile ? 'border-green-500 bg-green-50' : 'border-gray-300'}`}>
                      <input 
                        type="file" 
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange(e, setDlFile)}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                        required
                      />
                      {dlFile ? (
                        <div className="flex flex-col items-center text-green-700">
                           <Check className="w-8 h-8 mb-2" />
                           <p className="text-sm font-bold truncate max-w-full px-2">{dlFile}</p>
                           <p className="text-xs">Click to change</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                           <FileText className="w-8 h-8 text-gray-400 mb-2" />
                           <p className="text-sm font-bold text-gray-700">Upload DL</p>
                           <p className="text-xs text-gray-400">Front Side</p>
                        </div>
                      )}
                   </div>
                </div>

                {/* RC Upload */}
                <div className="space-y-2">
                   <label className="text-sm font-bold text-gray-700">Vehicle RC</label>
                   <div className={`border-2 border-dashed rounded-xl p-6 text-center hover:bg-gray-50 transition-colors cursor-pointer relative ${rcFile ? 'border-green-500 bg-green-50' : 'border-gray-300'}`}>
                      <input 
                        type="file" 
                        accept="image/*,.pdf"
                        onChange={(e) => handleFileChange(e, setRcFile)}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                        required
                      />
                       {rcFile ? (
                        <div className="flex flex-col items-center text-green-700">
                           <Check className="w-8 h-8 mb-2" />
                           <p className="text-sm font-bold truncate max-w-full px-2">{rcFile}</p>
                           <p className="text-xs">Click to change</p>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                           <FileText className="w-8 h-8 text-gray-400 mb-2" />
                           <p className="text-sm font-bold text-gray-700">Upload RC</p>
                           <p className="text-xs text-gray-400">Smart Card or PDF</p>
                        </div>
                      )}
                   </div>
                </div>
              </div>
            </div>

            <div className="pt-4">
              <button type="submit" className="w-full py-4 bg-black text-white rounded-xl font-bold text-lg hover:bg-gray-800 transition-colors shadow-lg flex items-center justify-center gap-2">
                Submit & Download App
              </button>
              <p className="text-center text-xs text-gray-500 mt-4">
                By submitting, you agree to our Partner Terms & Conditions and Privacy Policy.
              </p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default DriverRegistration;