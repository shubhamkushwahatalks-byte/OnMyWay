import React from 'react';
import { Zap, ShieldCheck, Car, Gift, Bike } from './Icons';

const Features: React.FC = () => {
  const features = [
    {
      icon: <Gift className="w-8 h-8 text-white" />,
      title: "Community Free Rides",
      description: "Join our movement to help each other. Many drivers offer free seats to help the community.",
      bg: "bg-green-500"
    },
    {
      icon: <Bike className="w-8 h-8 text-brand-contrast" />,
      title: "Autos & Taxis Too",
      description: "Not just carpools! Book your daily Auto rickshaw or Taxi with zero commission fees.",
      bg: "bg-brand"
    },
    {
      icon: <ShieldCheck className="w-8 h-8 text-white" />,
      title: "Verified Community",
      description: "Travel with peace of mind. We verify IDs and reviews to ensure a safe journey for everyone.",
      bg: "bg-blue-600"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-black text-gray-900 mb-4">Why choose On My Way?</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">We are more than just an app; we are a community moving forward together.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="group relative bg-white p-8 rounded-3xl border-2 border-gray-100 hover:border-transparent hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1">
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-transparent to-gray-50 rounded-bl-full -z-10 group-hover:scale-110 transition-transform`}></div>
              
              <div className={`w-16 h-16 rounded-2xl ${feature.bg} flex items-center justify-center mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                {feature.icon}
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed font-medium">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;