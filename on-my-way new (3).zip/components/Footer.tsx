import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-50 border-t border-gray-200 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Top Routes</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-brand-dark font-medium">Delhi → Chandigarh</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Mumbai → Pune</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Bangalore → Chennai</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Hyderabad → Vijayawada</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-gray-900 mb-4">About</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-brand-dark font-medium">How it works</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Our Story</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Safety</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Careers</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold text-gray-900 mb-4">Legal</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li><a href="#" className="hover:text-brand-dark font-medium">Terms of Service</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-brand-dark font-medium">Community Guidelines</a></li>
            </ul>
          </div>
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center text-brand-contrast font-black text-sm">OMW</div>
              <span className="font-black text-xl text-gray-800">On My Way</span>
            </div>
            <p className="text-sm text-gray-500">
              Connecting communities one ride at a time.
            </p>
          </div>
        </div>
        <div className="pt-8 border-t border-gray-200 text-center text-sm text-gray-500 font-medium">
          © 2024 On My Way Technologies. All rights reserved.
        </div>
      </div>
    </footer>
  );
};

export default Footer;