import React, { useState } from 'react';
import Header from './components/Header';
import HeroSearch from './components/HeroSearch';
import Features from './components/Features';
import AIPlanner from './components/AIPlanner';
import Footer from './components/Footer';
import DriverRegistration from './components/DriverRegistration';
import AppDownload from './components/AppDownload';
import { AppView, SearchParams, RideType } from './types';
import { Car, Star, User, ArrowRight, Bike, CarFront, Gift, MapPin } from './components/Icons';

function App() {
  const [currentView, setCurrentView] = useState<AppView>(AppView.LANDING);
  const [searchParams, setSearchParams] = useState<SearchParams | null>(null);

  const handleSearch = (params: SearchParams) => {
    setSearchParams(params);
    setCurrentView(AppView.SEARCH_RESULTS);
  };

  const handleDestinationSelect = (destination: string) => {
    setCurrentView(AppView.LANDING);
  };

  // Helper to get icon based on ride type
  const getRideIcon = (type: RideType | undefined) => {
    switch(type) {
      case RideType.AUTO: return <Bike className="w-5 h-5 text-gray-400" />;
      case RideType.TAXI: return <CarFront className="w-5 h-5 text-gray-400" />;
      default: return <Car className="w-5 h-5 text-gray-400" />;
    }
  };

  // Helper to generate mock prices based on type
  const getMockPrice = (basePrice: number, type: RideType | undefined, isFree: boolean) => {
    if (isFree) return 0;
    switch(type) {
      case RideType.AUTO: return Math.round(basePrice * 0.4); // Auto is cheaper
      case RideType.TAXI: return Math.round(basePrice * 1.5); // Taxi is expensiver
      default: return basePrice; // Carpool
    }
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header 
        currentView={currentView} 
        onNavigate={setCurrentView} 
      />

      <main className="flex-1">
        {currentView === AppView.LANDING && (
          <>
            {/* Hero Section */}
            <div className="relative bg-brand text-brand-contrast h-[420px] overflow-hidden">
               {/* Background Pattern/Image placeholder */}
               <div className="absolute inset-0 opacity-40 mix-blend-multiply bg-[url('https://images.unsplash.com/photo-1549520937-25e2e96d132d?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center"></div>
               <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
               
               <div className="container mx-auto px-4 h-full flex items-center justify-center relative z-10 pb-20">
                 <div className="text-center">
                    <span className="inline-block bg-white text-black text-xs font-bold px-3 py-1 rounded-full mb-4 uppercase tracking-widest shadow-lg">
                      #1 Community Travel App
                    </span>
                    <h1 className="text-5xl md:text-7xl font-black text-white drop-shadow-lg max-w-4xl leading-tight mb-2">
                     Get <span className="text-brand">On My Way</span>
                    </h1>
                    <p className="text-xl text-gray-100 font-medium mb-6 drop-shadow-md">
                      Carpools. Autos. Taxis. And free rides for those in need.
                    </p>
                 </div>
               </div>
            </div>

            {/* Floating Search Bar */}
            <HeroSearch 
              onSearch={handleSearch} 
              onNavigateAI={() => setCurrentView(AppView.AI_PLANNER)}
            />

            {/* Features Section */}
            <div className="mt-8">
               <Features />
            </div>

            {/* App Download Section */}
            <AppDownload />
          </>
        )}

        {currentView === AppView.AI_PLANNER && (
          <div className="bg-gray-50 min-h-[calc(100vh-64px)]">
            <AIPlanner onSelectDestination={handleDestinationSelect} />
          </div>
        )}

        {currentView === AppView.DRIVER_REGISTRATION && (
          <div className="bg-white min-h-[calc(100vh-64px)]">
             <DriverRegistration />
          </div>
        )}

        {currentView === AppView.SEARCH_RESULTS && (
          <div className="h-[calc(100vh-64px)] flex flex-col md:flex-row overflow-hidden">
            {/* Left Panel - Results */}
            <div className="w-full md:w-1/2 lg:w-5/12 h-full overflow-y-auto bg-gray-50 border-r border-gray-200">
               <div className="p-4 sticky top-0 bg-gray-50 z-10 border-b border-gray-200">
                  <div className="flex items-center gap-2 text-sm text-gray-500 mb-4">
                    <span className="cursor-pointer hover:text-brand-dark" onClick={() => setCurrentView(AppView.LANDING)}>Home</span>
                    <ArrowRight className="w-4 h-4" />
                    <span>Results</span>
                  </div>

                  <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                          <h3 className="font-bold text-lg text-gray-900">{searchParams?.from || 'Anywhere'} → {searchParams?.to || 'Anywhere'}</h3>
                          <button 
                            onClick={() => setCurrentView(AppView.LANDING)}
                            className="text-brand-dark text-sm font-bold hover:underline"
                          >
                            Edit
                          </button>
                      </div>
                      <div className="flex gap-3 text-xs font-medium text-gray-500">
                          <span className="bg-gray-100 px-2 py-1 rounded">{searchParams?.date}</span>
                          <span className="bg-gray-100 px-2 py-1 rounded">{searchParams?.passengers} Passenger(s)</span>
                          <span className="bg-gray-100 px-2 py-1 rounded">{searchParams?.type}</span>
                      </div>
                  </div>
               </div>

               <div className="p-4 space-y-4">
                 <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider px-1">
                    Available Rides (3)
                 </h3>

                 {/* Mock Results Logic */}
                  {[0, 1, 2].map((i) => {
                    const isFree = searchParams?.showFreeOnly || (searchParams?.type === RideType.CARPOOL && i === 1);
                    const effectivePrice = searchParams?.showFreeOnly ? 0 : getMockPrice(850 + (i * 120), searchParams?.type, isFree);

                    return (
                      <div key={i} className="bg-white border border-gray-200 rounded-2xl p-4 hover:shadow-lg transition-all cursor-pointer group hover:border-brand">
                        <div className="flex justify-between mb-4">
                          <div className="space-y-6 relative">
                            <div className="relative z-10 pl-4">
                              <div className="absolute left-0 top-1.5 w-2 h-2 rounded-full bg-gray-900 ring-2 ring-white"></div>
                              <div className="font-bold text-lg text-gray-900">09:00</div>
                            </div>
                            
                            <div className="absolute left-[3px] top-3 bottom-3 w-[2px] bg-gray-200"></div>
                            
                            <div className="relative z-10 pl-4">
                              <div className="absolute left-0 top-1.5 w-2 h-2 rounded-full bg-brand ring-2 ring-white"></div>
                              <div className="font-bold text-lg text-gray-900">14:30</div>
                            </div>
                          </div>
                          
                          <div className="text-right">
                             {effectivePrice === 0 ? (
                                 <div className="flex flex-col items-end">
                                     <div className="font-black text-2xl text-green-600 flex items-center gap-1">
                                       <Gift className="w-5 h-5" /> FREE
                                     </div>
                                 </div>
                             ) : (
                                 <div className="font-black text-2xl text-gray-900">₹{effectivePrice}</div>
                             )}
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between pt-3 border-t border-gray-50">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center overflow-hidden border border-gray-200">
                               {getRideIcon(searchParams?.type)}
                            </div>
                            <div>
                              <div className="font-bold text-sm text-gray-900">
                                  {searchParams?.type === RideType.AUTO ? 'Raju Auto' : searchParams?.type === RideType.TAXI ? 'City Taxi Co.' : 'Amit Sharma'}
                              </div>
                              <div className="flex items-center gap-1 text-xs font-medium text-gray-500">
                                <Star className="w-3 h-3 text-brand-dark fill-current" />
                                <span>4.{8 - i}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
               </div>
            </div>

            {/* Right Panel - Google Map */}
            <div className="hidden md:block w-1/2 lg:w-7/12 h-full bg-gray-200 relative">
               {/* Embed Google Map Iframe - Using search query for visual representation */}
               <iframe 
                 width="100%" 
                 height="100%" 
                 frameBorder="0" 
                 scrolling="no" 
                 marginHeight={0} 
                 marginWidth={0} 
                 src={`https://maps.google.com/maps?q=${encodeURIComponent(searchParams?.from || 'New Delhi')} to ${encodeURIComponent(searchParams?.to || 'Chandigarh')}&t=&z=7&ie=UTF8&iwloc=&output=embed`}
                 className="w-full h-full grayscale-[20%] hover:grayscale-0 transition-all duration-500"
               ></iframe>
               
               {/* Map Overlay Info */}
               <div className="absolute bottom-6 left-6 right-6 bg-white/90 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-white/50 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                      <div className="bg-brand p-2 rounded-full text-brand-contrast">
                          <MapPin className="w-5 h-5" />
                      </div>
                      <div>
                          <p className="text-xs font-bold text-gray-500 uppercase">Total Distance</p>
                          <p className="font-black text-gray-900">~245 km</p>
                      </div>
                  </div>
                  <button className="bg-black text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-800 transition-colors">
                      Open in Maps
                  </button>
               </div>
            </div>
          </div>
        )}
      </main>

      {/* Only show Footer on Landing and Driver Registration, simpler layout for Maps */}
      {currentView !== AppView.SEARCH_RESULTS && <Footer />}
    </div>
  );
}

export default App;