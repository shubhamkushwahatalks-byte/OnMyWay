import { GoogleGenAI, Type, Schema } from "@google/genai";
import { TripSuggestion } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getTripSuggestions = async (
  origin: string,
  vibe: string
): Promise<TripSuggestion[]> => {
  try {
    const schema: Schema = {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          destination: { type: Type.STRING, description: "Name of the destination city or area" },
          description: { type: Type.STRING, description: "Why it matches the requested vibe (max 20 words)" },
          estimatedPrice: { type: Type.STRING, description: "Estimated price range for a ride (e.g. $20-30)" },
          vibe: { type: Type.STRING, description: "A one or two word tag describing the place" }
        },
        required: ["destination", "description", "estimatedPrice", "vibe"]
      }
    };

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Suggest 3 carpooling destinations starting from ${origin || "Central City"} for someone looking for a "${vibe}" experience. Keep it realistic for a 2-5 hour drive.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        systemInstruction: "You are a helpful travel assistant for a carpooling app. You inspire users to travel."
      }
    });

    const text = response.text;
    if (!text) return [];
    
    return JSON.parse(text) as TripSuggestion[];
  } catch (error) {
    console.error("Gemini API Error:", error);
    return [];
  }
};